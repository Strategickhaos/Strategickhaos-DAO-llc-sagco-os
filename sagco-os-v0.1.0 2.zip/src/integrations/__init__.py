"""SAGCO OS External Integrations"""
